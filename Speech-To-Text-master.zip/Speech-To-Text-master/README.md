# Speech To Text
Aplicación desarrollada en Python para pasar de texto a voz y viceversa


Funciona solamente con Python 2.7 por lo temas de algunas librerias

Antes de correr la aplicacion asegurese de descargar los modulos necesarios con
$ pip install -r requirements.txt
